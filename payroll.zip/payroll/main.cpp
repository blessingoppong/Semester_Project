#include <iostream>
#include <vector>
#include <algorithm> // For sorting

using namespace std;



struct Employee {
    string name;
    double hourlyRate;
    double hoursWorked;
    double deductions;
    double benefits;
};



// calculate salary
double calculateSalary(const Employee& emp) {
    double grossPay = emp.hourlyRate * emp.hoursWorked;
    double netPay = grossPay - emp.deductions + emp.benefits;
    return netPay;
}



// employees name
bool compareByName(const Employee& emp1, const Employee& emp2) {
    return emp1.name < emp2.name;
}



int main() {

    // global variables
    bool program_still_runing = true;
    int user_input;
    bool number_of_records = true;
    int add_new_record_or_no;

    // employee records
    string name;
    double hourlyRate;
    double hoursWorked;
    double deductions;
    double benefits;


    vector<Employee> employees;




    while(program_still_runing){

        cout << "1. Add employee records "<<endl;
        cout << "2. Calculate and display salaries  "<<endl;
        cout << "3. Display all employees "<<endl;
        cout << "4. Close program "<<endl;

        cin >> user_input;

        if (user_input == 1){

            while (number_of_records){
                cout << "Enter records in the following format: \nname \nhourlyRate \nhoursWorked \ndeductions \nbenefits : " << endl;
                cin >> name;
                cin >> hourlyRate;
                cin >> hoursWorked;
                cin >> deductions;
                cin >> benefits;

                employees.push_back({name, hourlyRate, hoursWorked, deductions, benefits});

                cout << "Do you want to add another record: 1. Yes 2. No"<<endl;
                cin >> add_new_record_or_no;

                if (add_new_record_or_no == 1){

                   continue;
                }else{
                    number_of_records = false;
                }

            }
        }else if (user_input == 2){

            for (const Employee& emp : employees) {
            double salary = calculateSalary(emp);
                cout << emp.name << "'s Salary: $" << salary << endl;
            }

        }else if(user_input == 3){
            for (const Employee& emp : employees) {
                cout << emp.name << endl;
            }
        }else if(user_input == 4){
            cout << "Quitting the program";
            program_still_runing = false;
        }else{
            cout<< "You entered a wrong input. Please, enter a number from 1-4" <<endl;
        }


    }


    return 0;
}
